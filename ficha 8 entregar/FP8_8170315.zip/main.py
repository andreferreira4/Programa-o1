from random import randint
NUMERO_VEZES = 10
file = open("ex1.txt","a")


for i in range(NUMERO_VEZES): 
    numero = str(randint(0, 9)) + "\n"
    file.write(numero)
file.close()